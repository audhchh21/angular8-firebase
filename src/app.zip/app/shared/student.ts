export interface Student {
   $key: String;
   firstName: String;
   lastName: String;
   email: String
   mobileNumber: Number;
   faculty: String;
   major: String;
   year: Number;
   address: String;
}
